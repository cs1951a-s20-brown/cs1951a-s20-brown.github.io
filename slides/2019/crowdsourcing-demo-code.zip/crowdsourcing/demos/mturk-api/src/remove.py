"""
Crowdsourcing for NLP Tutorial
NAACL 2015

Script for removing the HITs from MTurk
"""

from boto.mturk.connection import MTurkConnection
from keys import keys

ACCESS_ID= keys['ACCESS_KEY'] #found on Amazon Web Services
SECRET_KEY = keys['SECRET_KEY'] #found on Amazon Web Services
HOST = 'mechanicalturk.sandbox.amazonaws.com'

conn = MTurkConnection(aws_access_key_id=ACCESS_ID, aws_secret_access_key=SECRET_KEY, host=HOST)
 
hits = conn.get_all_hits()
for hit in hits:
	print "removing HIT %s"%hit.HITId
	try : conn.disable_hit(hit.HITId)
	except : continue
