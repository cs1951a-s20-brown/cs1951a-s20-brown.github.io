"""
Crowdsourcing for NLP Tutorial
NAACL 2015

Script for approving assignments and paying workers
"""

import csv
import sys
from boto.mturk.connection import MTurkConnection
from boto.mturk.connection import MTurkRequestError
from keys import keys

#Parameters used for posting the HIT
ACCESS_ID= keys['ACCESS_KEY'] #found on Amazon Web Services
SECRET_KEY = keys['SECRET_KEY'] #found on Amazon Web Services
HOST = 'mechanicalturk.sandbox.amazonaws.com'

#If you are QCing your HITs, you can use the messages to provide feedback to Turkers about what they are doing well/poorly. See the code in full-qc-example.
MSG = "Thank you for doing our HIT!"

conn = MTurkConnection(aws_access_key_id=ACCESS_ID, aws_secret_access_key=SECRET_KEY, host=HOST)

for row in csv.DictReader(open(sys.argv[1])):
	assignment = row['AssignmentId']
	try : conn.approve_assignment(assignment, feedback=MSG)
	except MTurkRequestError : continue 
	#When you approve an assignment, it is not removed from your queue of HITs, so you will still download it everytime you call get_all_hits(). If this assignment has already been approved/rejected, boto will thorugh an error.  To remove the assignment completely you can use disable_hit(), but this will remove all of the data from all workers who complete this assignment, and you will not be able to download it again. I prefer not to use disable_hit() until I know I am completely done with the HITs, so I know I can recover the data in case something goes wrong or it gets lost/corrupted.
