"""
Crowdsourcing for NLP Tutorial
NAACL 2015

Script for posting a simple paraphrase judgement HIT to CrowdFlower
This script is based off of the documentation given at https://github.com/peoplepattern/crowdflower
"""

import csv
import crowdflower

#Set up a connection with CrowdFlower
conn = crowdflower.Connection(api_key='YOUR_API_KEY') #found on CrowdFlower account main page
#Tag which will help us identify the HIT in the future
tag = 'naacl-tutorial'

#Data is a list of dictionaries, where each dictionary corresponds to a row in the csv
data = [row for row in csv.DictReader(open('input/paraphrase_input.csv'))]

#Upload the data to CF
job = conn.upload(data)

#Instructions are given as an html string
instructions = open('input/instructions.html').read()

#Pass the code (using crowdflower markup language i.e. CML) as a string. Like on the web interface, this code corresponds to an individual "unit" or question
cml = ('{{sentence}}\n<cml:checkboxes label="Please select all good paraphrases of &quot;{{phrase}}&quot; from the below list:" validates="required" name="paraphrases">'+
'<cml:checkbox label="{{paraphrase0}}"></cml:checkbox>\n'+
'<cml:checkbox label="{{paraphrase1}}"></cml:checkbox>\n'+
'<cml:checkbox label="{{paraphrase2}}"></cml:checkbox>\n'+
'<cml:checkbox label="{{paraphrase3}}"></cml:checkbox>\n'+
'<cml:checkbox label="{{paraphrase4}}"></cml:checkbox>\n'+
'<cml:checkbox label="{{paraphrase5}}"></cml:checkbox>\n'+
'<cml:checkbox label="None of these are good paraphrases."></cml:checkbox>'+
'</cml:checkboxes>')

#The update() command posts the job to the web interface but does not launch it.
update_result = job.update({
  'title': 'Choose good paraphrases for a phrase',
  'included_countries': ['US', 'GB'],  # Limit to English speaking countries
  'payment_cents': 5,
  'judgments_per_unit': 1,
  'instructions': instructions, 
  'cml': cml,
  'options': {'front_load': 1,} #1 = quiz mode, 0 = regular
})

#Add a tag so we can identify the job later    
job.tags = [tag]

#Launch the job
job.launch(200, channels=['cf_internal'])
