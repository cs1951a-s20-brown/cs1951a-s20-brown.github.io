"""
Crowdsourcing for NLP Tutorial
NAACL 2015

Script for downloading results of posted HIT 
This script is based off of the documentation given at https://github.com/peoplepattern/crowdflower
"""

import json
import crowdflower

#Set up a connection with CrowdFlower
conn = crowdflower.Connection(api_key='YOUR_API_KEY') #found on CrowdFlower account main page
#Tag which will help us identify the HIT in the future
tag = 'naacl-tutorial'

#Find the job based on the tag specified in post.py
def _find_job():
    for job in conn.jobs():
        if tag in job.tags:
            return job

job = _find_job()

for judgment in job.judgments:
	print json.dumps(judgment)

