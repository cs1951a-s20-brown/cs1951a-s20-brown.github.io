#!/bin/python

from boto.mturk.qualification import Qualifications, NumberHitsApprovedRequirement, PercentAssignmentsApprovedRequirement, LocaleRequirement

settings = {

	'ACCESS_ID' : 'AKIAIIYIZ3DOK5IXADDQ',
	'SECRET_KEY' : '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',
	'HOST' : 'mechanicalturk.sandbox.amazonaws.com',
	'MAX_HITS' : 10,
	'PHRASES_PER_HIT' : 10,
	'PRICE' : 0.15,
	'REDUNDANCY' : 1,
	'DURATION' : 60*60,
	'TITLE' : "Choose good paraphrases for a phrase",
	'DESCRIPTION' : ("Choose good paraphrases for words in a sentence."),
	'INSTRUCTIONS' : 'input/instructions.txt',
	'KEYWORDS' : 'Research, English, language',
	'QUALIFICATIONS' : [NumberHitsApprovedRequirement('GreaterThanOrEqualTo', 50), 
		PercentAssignmentsApprovedRequirement('GreaterThanOrEqualTo', 90),
		LocaleRequirement('EqualTo', 'US')],
	'DATA_FILE' : 'input/wikipedia.tsv',
	'CONTROL_FILE' : 'input/controls.tsv',
}

