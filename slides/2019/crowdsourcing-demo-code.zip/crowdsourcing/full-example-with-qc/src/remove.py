from boto.mturk.connection import MTurkConnection
from settings import settings

ACCESS_ID = settings['ACCESS_ID']
SECRET_KEY = settings['SECRET_KEY']
HOST = settings['HOST']

conn = MTurkConnection(aws_access_key_id=ACCESS_ID, aws_secret_access_key=SECRET_KEY, host=HOST)
 
hits = conn.get_all_hits()
i = 0
for hit in hits:
	g = conn.get_hit(hit.HITId, response_groups=['HITDetail'])[0].HITGroupId 
	print "removing HIT %s"%hit.HITId
	try : conn.disable_hit(hit.HITId)
	except : continue
