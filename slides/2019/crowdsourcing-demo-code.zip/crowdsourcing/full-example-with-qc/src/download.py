from boto.mturk.connection import MTurkConnection
from boto.mturk.connection import MTurkRequestError
from boto.ecs.item import ResponseGroup, Item
import csv
import time
import sys
from settings import settings
import codecs

#download all HITs that have been submitted
conn = MTurkConnection(aws_access_key_id=settings['ACCESS_ID'], aws_secret_access_key=settings['SECRET_KEY'], host=settings['HOST'])
hits = conn.get_all_hits()

headers = set()
rows = []
for hit in hits:
    assignments = conn.get_assignments(hit.HITId, response_groups=['Minimal'])
    for assignment in assignments:
	results = {}
	h = conn.get_hit(assignment.HITId, response_groups=['HITDetail', 'HITQuestion'])[0]
	#Save the metadate associated with this assignment
	results['HITId'] = assignment.HITId
	results['HITGroupId'] = h.HITGroupId
	results['AssignmentId'] = assignment.AssignmentId
	results['WorkerId'] = assignment.WorkerId
	results['AcceptTime'] = assignment.AcceptTime
	results['SubmitTime'] = assignment.SubmitTime
	#Save the Turkers' reponse to each question
	for i,question_form_answer in enumerate(assignment.answers[0]):
		qid = question_form_answer.qid
		id, pos, w, sent, knownpos, knownneg = qid.split(' ||| ')
		answer = '|'.join([p.encode('utf') for p in question_form_answer.fields])
		results['Input.id%d'%i] = id 
		results['Input.pos%d'%i] = pos.encode('utf-8')
		results['Input.w%d'%i] = w.encode('utf-8')
		results['Input.sent%d'%i] = sent.encode('utf-8')
		results['Input.known_pos%d'%i] = knownpos.encode('utf-8')
		results['Input.known_neg%d'%i] = knownneg.encode('utf-8')
		results['Answer.paraphrases%d'%i] = answer
	headers.update(set(results.keys()))
	rows.append(results)

#Save all of the data to a csv file
headers = list(headers)
date = time.strftime("%m-%d-%YT%H:%M")
outfile = csv.DictWriter(codecs.open('ungraded.%s.csv'%date, mode='w'), delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL, fieldnames=headers)
outfile.writeheader()
for row in rows : 
	outfile.writerow(row)

